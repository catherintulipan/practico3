﻿Imports MySql.Data.MysqlClient
Public Class Form1
    Private Sub btnConectar_Click(sender As Object, e As EventArgs) Handles btnConectar.Click
        Dim conexion As MySqlConnection
        conexion = New MySqlConnection

        Dim a As New MySqlCommand

        conexion.ConnectionString = "server=localhost; database=encuesta;Uid=root;Pwd=;"

        If (txtNombre.Text = "" Or txtApellido.Text = "" Or Series.Text = "") Then
            MsgBox("No ha ingresado todos los datos.")
        Else
            Try
                conexion.Open()
                MsgBox("Conectado con la base de datos.")
                a.Connection = conexion

                a.CommandText = "INSERT INTO encuestas_series (nombre, apellido, serie_favorita) VALUES(@nombre,@apellido,@serie_favorita)"
                a.Prepare()

                a.Parameters.AddWithValue("@nombre", txtNombre.Text)
                a.Parameters.AddWithValue("@apellido", txtApellido.Text)
                a.Parameters.AddWithValue("@serie_favorita", Series.Text)
                a.ExecuteNonQuery()

                conexion.Close()
                txtNombre.Clear()
                txtApellido.Clear()
                Series.Text = ""
                MsgBox("Sus datos se han ingresado correctamente.")





            Catch ex As Exception
                MsgBox("No se pudo conectar con la base de datos.")
            End Try

        End If



    End Sub
End Class
